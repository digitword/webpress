<?php get_header('taggle');?>

<div class="jumbotron jumbotron-fluid">
    <div class="container">
        <h1 class="display-4">Our Planet</h1>
        <p class="lead">Experience our planet's natural beauty and examine how climate 
            change impacts all living creatures in this ambitious documentary of spectacular scope.</p>
        
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/um2Q9aUecy0" allowfullscreen></iframe>
        </div>
        </div>
    </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-sm">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/6v2L2UGZJAM" allowfullscreen></iframe>
        </div>
     </div>
    <div class="col-sm">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/JkaxUblCGz0" allowfullscreen></iframe>
        </div> 
    </div>
    <div class="col-sm">
        <div class="embed-responsive embed-responsive-16by9">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/9FqwhW0B3tY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>        </div> 
    </div>
        
  </div>
</div>


<?php get_footer();?>