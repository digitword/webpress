<?php get_header('slidepanel');?>

<div id="slide">
    <div class="card">
      
      <div class="card-body">

        <h5 class="card-title">GitHub overview</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="https://github.com/digitword" class="btn btn-primary">GitHub overview</a>
      
    
        <h5 class="card-title">GitHub Page</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="https://github.com/digitword" class="btn btn-primary">GitHub page</a>
      
    
        <h5 class="card-title">LinkedIn </h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="https://github.com/digitword" class="btn btn-primary">LinkedIn</a>

      </div>
    </div>  
<div>

<?php get_footer();?>
