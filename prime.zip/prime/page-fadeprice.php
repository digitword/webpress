<?php get_header('swup');?>

<div class="container">
    </br></br>
        <div>
          <li><a href="http://pupaak.test/fadehome/">Home</a></li>
          <li><a href="http://pupaak.test/fadeprice/">Priceing</a></li>
          <li><a href="http://pupaak.test/fadeabout/">About</a></li>
        </div>


            <h1>This is the pricing page!</h1>


</div>
<?php get_footer('swup');?>