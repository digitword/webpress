<?php get_header();?>

<div id="shopppinganimate"> 
    <nav>
        <div class="nav-closed">
            <h2>Portfolio</h2>
            <ul class="nav-links">
                <li class="nav-botton">Shop</li>
                <li>Blog</li>
                <li>Contact</li>
            </ul>
        </div>
        <div class="nav-open">
            <div class="clothing">
                <h2>Clothes</h2>
                <ul>
                    <li><a href="http://">Hats</a></li>
                    <li><a href="http://">Swimsuit</a></li>
                    <li><a href="http://">Underware</a></li>
                    <li><a href="http://">Mics</a></li>
                </ul>
            </div>
            <div class="nav-images">
                <img src="http://saas.test./wp-content/uploads/2020/12/hoodie.jpeg" alt="">
                <img src="http://saas.test./wp-content/uploads/2020/12/hats.jpeg" alt="">
            </div>
        </div>
    </nav>

    <div class="cover-image">
        <img src="http://saas.test./wp-content/uploads/2020/12/long-cover-scaled.jpg" alt="">
    </div>
    <div class="cover-date">
        <h1>05/12/2020</h1>
    </div>

</div>

<?php get_footer();?>