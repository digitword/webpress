<!DOCTYPE html>


<html lang="en">
<head>
  <meta charset="utf-8">

  <title>Pupaak, wordpress</title>
  <title>Documentry</title>

  <?php wp_head();?>

</head>
<body>