<?php get_header('demonav3');?>

<div class="container">
    <div id="nav3"> 
     <h1>A page with different menu items!</h1>
    </div>
</div>

<?php get_footer();?>