
<?php get_header('taggle');?>

<div class="container">

<br></br>
<br></br>
<br></br>

<h3>"This is the day the Lord has made;
We will rejoice and be glad in it." Psalm 118:24<span>&nbsp;</span></h3> 
</div>

<?php get_footer('pupaak');?>
