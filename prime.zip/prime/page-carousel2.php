<?php get_header('taggle');?>

<div id="carousel2">

    <div class="container">
            <h2>A carousel with controls and indicators<h2>
    </div>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
        <img class="d-block w-100" src="http://pupaak.test/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="First slide">
        <div class="carousel-caption d-none d-md-block">
            <h5>First slide label</h5>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
        </div>
        <div class="carousel-item">
        <img class="d-block w-100" src="http://pupaak.test/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Second slide">
        <div class="carousel-caption d-none d-md-block">
            <h5>Second slide label</h5>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
        </div>
        <div class="carousel-item">
        <img class="d-block w-100" src="http://pupaak.test/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
        <div class="carousel-caption d-none d-md-block">
            <h5>Third slide label</h5>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
        </div>
    </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>
<?php get_footer('demofoot2');?>