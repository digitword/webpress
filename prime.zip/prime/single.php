<?php get_header('demonav3');?>
<section class="page-wrap">
    <div class="container">
        <br></br>
        

        <!--- In additon to blog we can use thumbnails for pages as well
        just copy and paste this part in the page--->
        <?php if(has_post_thumbnail()):?>
            <img src="<?php the_post_thumbnail_url('blog-large');?>" alt="<?php the_title();?>"
            class="img-fluid mb-3 img-thumbnail">
        <?php endif;?>
        

        <br></br>
        <h3><?php the_title();?></h3>
        <br></br>
        <?php get_template_part('includes/section','blogcontent');?>
        
        <!---ALT+Shipft+P ** for page break-->
        <?php wp_link_pages();?>
        
    </div>
</section>
<?php get_footer();?>

<!----

https://wpshout.com/get-template-part/

https://www.wpbeginner.com/wp-themes/how-to-create-category-templates-in-wordpress/


--->