<?php get_header();?>

<div id="grid2">
    <h2>Alignment</h2>
    <p>Vertical alignment</p>
    <div class="container">
        
        <div class="row align-items-end">
            <div class="col">
            One of three columns
            </div>
            <div class="col">
            One of three columns
            </div>
            <div class="col">
            One of three columns
            </div>
        </div>

    </div><!----container--->
</div><!--grid1--->

<?php get_footer();?>