<?php 
/*
Template Name: frontpage/Home
*/
?>


<?php get_header();?>

<div class="container">
 <!--<h3>This website will be on board from 1 Decemebr 2020. 
 Do not forget to check it out!<span>&nbsp;</span></h3></div>-->

    <h1><?php the_title();?></h1>
    <?php get_template_part('includes/section' , 'content');?>


        <div id="pupaak"> 
                
                <video loop muted autoplay preload="auto">
                    <source src="https://pupaak.com/wp-content/uploads/2020/12/lastwithtext.mp4" type="video/mp4">
                    Your brower does not support the video tag.
                </video>        
                <div class="caption">
                    <a class="btn btn-outline-secondary btn-sm"
                    href="http://pupaak.test/ui/" role="button">Back</a>
                    </button>   
            </div>
        </div>              

   

</div>
<!---- add image loading Moziallz--->
<!--https://wickydesign.com/9-simple-add-ons-you-should-consider-for-your-website/ --->
<?php get_footer('pupaak');?>
