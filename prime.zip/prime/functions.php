<?php


/*Adding style sheet, javascripts and jquery*/
function scripts(){
  wp_register_style('style', get_template_directory_uri() . '/dist/app.css' , [] , 'all');
  wp_enqueue_style('style');
           
  wp_register_script('app', get_template_directory_uri() . '/dist/app.js' , ['jquery'] , true);
  wp_enqueue_script('app');
  wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'scripts');



//Theme Options
add_theme_support('menus');
add_theme_support('post-thumbnails');
add_theme_support('widgets');


//You can style your widgets in your stylesheet (in class widget)
function my_sidebars()
{
      register_sidebar( array(
        'name'          => 'Page Sidebar',
        'id'            => 'page-sidebar',
        'before_widget' => '<ul><li id="%1$s" class="widget %2$s">',
        'after_widget'  => '</li></ul>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>'
      ) );
      register_sidebar( array(
        'name'          => 'Blog Sidebar',
        'id'            => 'blog-sidebar',
        'before_widget' => '<ul><li id="%1$s" class="widget %2$s">',
        'after_widget'  => '</li></ul>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>'
      ) );
}
add_action('widgets_init','my_sidebars');


//custom image sizes
add_image_size('blog-large', 800, 400, true);
// for hard crop
add_image_size('blog-small', 300, 200, true);
// plugin : force regenerate thumbnails plugin for consostancy 


/* Add multiple menus to your site*/
function register_my_menus() {
  register_nav_menus(
    array(
      'first-menu' => __( 'First Menu' ),
      'second-menu' => __( 'Second Menu' ),
      'third-menu' => __( 'Third Menu' ),
      'footerabout-menu' => __( 'Footerabout Menu' ),
      'footerresources-menu' => __( 'Footerresources Menu' ),
      'footercontact-menu' => __( 'Footercontact Menu' )
    )
  );
}
add_action( 'init', 'register_my_menus' );


// The proper way to enqueue GSAP script in WordPress
// wp_enqueue_script( $handle, $src, $deps, $ver, $in_footer );
function theme_gsap_script(){
wp_enqueue_script( 'gsap-js', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.3.0/gsap.min.js', array(), false, true );
wp_enqueue_script( 'gsap-js2', get_template_directory_uri() . '/dist/app.js', array(), false, true );
}add_action( 'wp_enqueue_scripts', 'theme_gsap_script' );


function wpb_hook_javascript() {
    if (is_page ('417') ){ 
      ?>
        <script>
              alert("Hello! I am an alert box!");
            
        </script>  
    <?php
      
    }
  }
  add_action('wp', 'wpb_hook_javascript');


function wpb_pagination_javascript() {
    if (is_page ('453')) { 
      ?>
        <script>

              
       </script>
    <?php
      
    }
  }
  add_action('wp_head', 'wpb_pagination_javascript');


function wpb_hook_javascript_footer() {
//function wpb_hook_javascript_header() {
  
  
}
add_action('wp_footer', 'wpb_hook_javascript_footer');
//add_action('wp_header', 'wpb_hook_javascript_footer');





 
?>