<!DOCTYPE html>
<main id="swup" class="transition-slide">


<html lang="en">
<head>
  <meta charset="utf-8">

  <title>Pupaak, wordpress, themes and themplates</title>
  <title>Documentry</title>

  <?php wp_head();?>

</head>
<body>

<header>
    <nav id="site-navigation" class="taggle-navigation" role="navigation">
        <button class="menu-toggle">Menu</button>
        <?php wp_nav_menu( array( 'theme_location' => 'first-menu'  , 'menu_class' => 'nav-menu') ); ?>
    </nav>
</header>




