<?php get_header();?>

<div class="container">
 <!--<h3>This website will be on board from 1 Decemebr 2020. 
 Do not forget to check it out!<span>&nbsp;</span></h3></div>-->

    <div id="vidoeback"> 
            
            <video loop muted autoplay preload="auto">
                <source src="https://pupaak.com/wp-content/uploads/2020/12/video.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <!--        
            <div class="caption">
                <h2>Welcome to my WordPress world<h2>
                <a class="btn btn-outline-secondary btn-sm"
                href="https://pupaak.com/gateway/" role="button">Themes and Templates</a>
                </button>   
           </div>
           -->
    </div>    

</div>

<?php get_footer('pupaak');?>
