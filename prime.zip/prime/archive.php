<?php get_header('demonav3');?>

<section class="page-wrap">
    <div class="container">
        <br></br> 
        <div class="row">
                <div class="col-lg-3">
                    <?php if ( is_active_sidebar( 'blog-sidebar' ) ) : ?>
                        <?php dynamic_sidebar( 'blog-sidebar' ); ?>
                        <?php //wp_get_archives( array( 'type' => 'monthly' ) ); ?>
                    <?php endif; ?>
                </div>
                <div class="col-lg-9">
                    <h1><?php echo single_cat_title();?></h1>
                    <br></br>
                    <!---
                    <?php //if(has_post_thumbnail()):?>
                        <img src="<?php //the_post_thumbnail_url('blog-small');?>" alt="<?php //the_title();?>"
                        class="img-fluid mb-3 img-thumbnail">
                    <?php //endif;?>
                    --->
                    <!-- This is our loop--->
                    <?php get_template_part('includes/section','archive');?>
                    
                    <!----this is the first way for pagiantion (after limiting the numbe rof posts in a page in setting)-->
                    <?php //previous_posts_link();?>
                    <?php //next_posts_link();?>

                    <!--This is numenrical pagiantion--->
                    <?php
                        /** 
                         * Create numeric pagination in WordPress
                         */
                        
                        // Get total number of pages
                        global $wp_query;
                        $total = $wp_query->max_num_pages;
                        // Only paginate if we have more than one page
                        if ( $total > 1 )  {
                            // Get the current page
                            if ( !$current_page = get_query_var('paged') )
                                $current_page = 1;
                            // Structure of “format” depends on whether we’re using pretty permalinks
                            $format = empty( get_option('permalink_structure') ) ? '&page=%#%' : 'page/%#%/';
                            echo paginate_links(array(
                                'base' => get_pagenum_link(1) . '%_%',
                                'format' => $format,
                                'current' => $current_page,
                                'total' => $total,
                                'mid_size' => 4,
                                //'type' => 'list'
                            ));
                        }
                    ?>
                </div>
        </div>
    </div>
</section>


<?php get_footer();?>

<!-----

If category.php does not exist, WordPress will look for a generic archive template, archive.php.
https://developer.wordpress.org/themes/basics/template-hierarchy/

-->