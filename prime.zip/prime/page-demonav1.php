<?php get_header();?>

<div class="container">
    <div id="nav1"> 
        <h1>A page without navigation bar!</h1>
    </div>
</div>

<?php get_footer();?>