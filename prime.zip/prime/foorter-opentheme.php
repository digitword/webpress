<?php wp_footer();?>


<scripts src="./src/myscripts.js"></scripts>

</body>
</html>