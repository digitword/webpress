<?php get_header('demonav2');?>

<div class="container">
    <div id="nav2"> 
     <h1>A page with different navigation colour style!</h1>
    </div>
</div>


<?php get_footer();?>