<?php get_header();?>

<div class="cotainer">

    <div id='stickycursor'>
        
          <header id="header">
            <div class="wrap">
              <ul>
                <li>
                  <a class="link" href="#s1">section 1</a>
                </li>
                <li>
                  <a class="link" href="#s2">section 2</a>
                </li>
                <li>
                  <a class="link" href="#s3">section 3</a>
                </li>
              </ul>
            </div>
          </header>
          <div id="intro">
            <div class="wrap">
              <h1>intro</h1>
            </div>
          </div>
          <main id="main">
            <section id="s1">
              <div class="wrap">
                <h2>section 1</h2>
              </div>
            </section>
            <section id="s2">
              <div class="wrap">
                <h2>section 2</h2>
              </div>
            </section>
            <section id="s3">
              <div class="wrap">
                <h2>section 3</h2>
              </div>
            </section>  
          </main>
    </div>
</div>


<?php get_footer();?>