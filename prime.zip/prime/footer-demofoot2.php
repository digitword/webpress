<?php wp_footer();?>

<div id="foot2">
  <footer>
      <!-- Footer main -->
      <section class="ft-main">
        <div class="ft-main-item">
          <h2 class="ft-title">About</h2>
          <?php wp_nav_menu( array( 'theme_location' => 'footerabout-menu'  , 'menu_class' => 'nav-menu') ); ?>
        </div>
        <div class="ft-main-item">
          <h2 class="ft-title">Resources</h2>
          <?php wp_nav_menu( array( 'theme_location' => 'footerresources-menu'  , 'menu_class' => 'nav-menu') ); ?>
        </div>
        <div class="ft-main-item">
          <h2 class="ft-title">Contact</h2>
          <?php wp_nav_menu( array( 'theme_location' => 'footercontact-menu'  , 'menu_class' => 'nav-menu') ); ?>
        </div>
        <div class="ft-main-item">
          <h2 class="ft-title">Stay Updated</h2>
          <p>Subscribe to our newsletter to get our latest news.</p>
          <form>
            <input type="email" name="email" placeholder="Enter email address">
            <input type="submit" value="Subscribe">
          </form>
        </div>
      </section>

      <!-- Footer social -->
      <section class="ft-social">
        <ul class="ft-social-list">
          <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          <li><a href="#"><i class="fab fa-github"></i></a></li>
          <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
          <li><a href="#"><i class="fab fa-youtube"></i></a></li>
        </ul>
      </section>
      
      <!-- Footer legal -->
      <section class="ft-legal">
        <ul class="ft-legal-list">
          <li><a href="#">Terms &amp; Conditions</a></li>
          <li><a href="#">Privacy Policy</a></li>
          <li>&copy; 2020 Copyright Pupaak Inc.</li>
        </ul>
      </section>
  </footer>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
</body>
</html>