<?php //get_header('slidepanel');?>
<?php get_header();?>
<?php //get_header('demonav5');?>

<div class="container">
 <!--<h3>This website will be on board from 1 Decemebr 2020. 
 Do not forget to check it out!<span>&nbsp;</span></h3></div>-->

    <div id="videobackcap"> 
            
            <video loop muted autoplay preload="auto">
                <source src="https://pupaak.com/wp-content/uploads/2020/12/video.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <div class="caption">
                <h1>One Planet</h1>                
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
 
    </div>    

</div>

<?php get_footer();?>

