<?php get_header();?>

<div id="grid1">
    <div class="container">
        <p>Container layout Small ≥576px</p>
        <div id="first">
            <div class="row">
                <div class="col-sm">
                12
                </div>
            </div>
        </div>
        <div id="second">
            <div class="row">
                <div class="col-sm">
                6 of 12
                </div>
                <div class="col-sm">
                12 of 12
                </div>            
            </div>
        </div>
        <div id="third">
            <div class="row">
                <div class="col-sm">
                3 of 12
                </div>
                <div class="col-sm">
                6 of 12
                </div>
                <div class="col-sm">
                9 of 12
                </div>
                <div class="col-sm">
                12 of 12
                </div>
            </div>
        </div>
        <div id="forth">
            <div class="row">            
                <div class="col-sm">
                4 of 12
                </div>
                <div class="col-sm">
                8 of 12
                </div>
                <div class="col-sm">
                12 of 12
                </div>
            </div>
        </div>
        <div id="fifth">
            <div class="row">
                <div class="col-sm">
                2 of 12
                </div>
                <div class="col-sm">
                4 of 12
                </div>
                <div class="col-sm">
                6 of 12
                </div>
                <div class="col-sm">
                8 of 12
                </div>
                <div class="col-sm">
                10 of 12
                </div>
                <div class="col-sm">
                12 of 12
                </div>
            </div>
        </div>
        <div id="sixth">
            <div class="row">
                <div class="col-sm">
                1 of 12  
                </div>
                <div class="col-sm">
                2 of 12  
                </div>
                <div class="col-sm">
                3 of 12 
                </div>
                <div class="col-sm">
                4 of 12 
                </div>
                <div class="col-sm">
                5 of 12  
                </div>
                <div class="col-sm">
                6 of 12  
                </div>
                <div class="col-sm">
                7 of 12  
                </div><div class="col-sm">
                8 of 12  
                </div><div class="col-sm">
                9 of 12  
                </div><div class="col-sm">
                10 of 12  
                </div><div class="col-sm">
                11 of 12  
                </div><div class="col-sm">
                12 of 12  
                </div>
            </div>
        </div>


        <p>Container layout Medium ≥768px</p>
        <div id="first">
            <div class="row">
                <div class="col-md">
                12
                </div>
            </div>
        </div>
        <div id="second">
            <div class="row">
                <div class="col-md">
                6 of 12
                </div>
                <div class="col-md">
                12 of 12
                </div>            
            </div>
        </div>
        <div id="third">
            <div class="row">
                <div class="col-md">
                3 of 12
                </div>
                <div class="col-md">
                6 of 12
                </div>
                <div class="col-md">
                9 of 12
                </div>
                <div class="col-md">
                12 of 12
                </div>
            </div>
        </div>
        <div id="forth">
            <div class="row">            
                <div class="col-md">
                4 of 12
                </div>
                <div class="col-md">
                8 of 12
                </div>
                <div class="col-md">
                12 of 12
                </div>
            </div>
        </div>
        <div id="fifth">
            <div class="row">
                <div class="col-md">
                2 of 12
                </div>
                <div class="col-md">
                4 of 12
                </div>
                <div class="col-md">
                6 of 12
                </div>
                <div class="col-md">
                8 of 12
                </div>
                <div class="col-md">
                10 of 12
                </div>
                <div class="col-md">
                12 of 12
                </div>
            </div>
        </div>
        <div id="sixth">
            <div class="row">
                <div class="col-md">
                1 of 12  
                </div>
                <div class="col-md">
                2 of 12  
                </div>
                <div class="col-md">
                3 of 12 
                </div>
                <div class="col-md">
                4 of 12 
                </div>
                <div class="col-md">
                5 of 12  
                </div>
                <div class="col-md">
                6 of 12  
                </div>
                <div class="col-md">
                7 of 12  
                </div>
                <div class="col-md">
                8 of 12  
                </div>
                <div class="col-md">
                9 of 12  
                </div>
                <div class="col-sm">
                10 of 12  
                </div>
                <div class="col-md">
                11 of 12  
                </div>
                <div class="col-md">
                12 of 12  
                </div>
            </div>
        </div>



        <p>Container layout Large ≥992px</p>
        <div id="first">
            <div class="row">
                <div class="col-lg">
                12
                </div>
            </div>
        </div>
        <div id="second">
            <div class="row">
                <div class="col-lg">
                6 of 12
                </div>
                <div class="col-lg">
                12 of 12
                </div>            
            </div>
        </div>
        <div id="third">
            <div class="row">
                <div class="col-lg">
                3 of 12
                </div>
                <div class="col-lg">
                6 of 12
                </div>
                <div class="col-lg">
                9 of 12
                </div>
                <div class="col-lg">
                12 of 12
                </div>
            </div>
        </div>
        <div id="forth">
            <div class="row">            
                <div class="col-lg">
                4 of 12
                </div>
                <div class="col-lg">
                8 of 12
                </div>
                <div class="col-lg">
                12 of 12
                </div>
            </div>
        </div>
        <div id="fifth">
            <div class="row">
                <div class="col-lg">
                2 of 12
                </div>
                <div class="col-lg">
                4 of 12
                </div>
                <div class="col-lg">
                6 of 12
                </div>
                <div class="col-lg">
                8 of 12
                </div>
                <div class="col-lg">
                10 of 12
                </div>
                <div class="col-lg">
                12 of 12
                </div>
            </div>
        </div>
        <div id="sixth">
            <div class="row">
                <div class="col-lg">
                1 of 12  
                </div>
                <div class="col-lg">
                2 of 12  
                </div>
                <div class="col-lg">
                3 of 12 
                </div>
                <div class="col-lg">
                4 of 12 
                </div>
                <div class="col-lg">
                5 of 12  
                </div>
                <div class="col-lg">
                6 of 12  
                </div>
                <div class="col-lg">
                7 of 12  
                </div>
                <div class="col-lg">
                8 of 12  
                </div>
                <div class="col-lg">
                9 of 12  
                </div>
                <div class="col-lg">
                10 of 12  
                </div>
                <div class="col-lg">
                11 of 12  
                </div>
                <div class="col-lg">
                12 of 12  
                </div>
            </div>
        </div>


    </div> <!---container-->

    <br></br>
    <div class="container-fluid">
        <p>Container fluid layout Small ≥576px</p>
        <div id="first">
            <div class="row">
                <div class="col-sm">
                12
                </div>
            </div>
        </div>
        <div id="second">
            <div class="row">
                <div class="col-sm">
                6 of 12
                </div>
                <div class="col-sm">
                12 of 12
                </div>            
            </div>
        </div>
        <div id="third">
            <div class="row">
                <div class="col-sm">
                3 of 12
                </div>
                <div class="col-sm">
                6 of 12
                </div>
                <div class="col-sm">
                9 of 12
                </div>
                <div class="col-sm">
                12 of 12
                </div>
            </div>
        </div>
        <div id="forth">
            <div class="row">            
                <div class="col-sm">
                4 of 12
                </div>
                <div class="col-sm">
                8 of 12
                </div>
                <div class="col-sm">
                12 of 12
                </div>
            </div>
        </div>
        <div id="fifth">
            <div class="row">
                <div class="col-sm">
                2 of 12
                </div>
                <div class="col-sm">
                4 of 12
                </div>
                <div class="col-sm">
                6 of 12
                </div>
                <div class="col-sm">
                8 of 12
                </div>
                <div class="col-sm">
                10 of 12
                </div>
                <div class="col-sm">
                12 of 12
                </div>
            </div>
        </div>
        <div id="sixth">
            <div class="row">
                <div class="col-sm">
                1 of 12  
                </div>
                <div class="col-sm">
                2 of 12  
                </div>
                <div class="col-sm">
                3 of 12 
                </div>
                <div class="col-sm">
                4 of 12 
                </div>
                <div class="col-sm">
                5 of 12  
                </div>
                <div class="col-sm">
                6 of 12  
                </div>
                <div class="col-sm">
                7 of 12  
                </div><div class="col-sm">
                8 of 12  
                </div><div class="col-sm">
                9 of 12  
                </div><div class="col-sm">
                10 of 12  
                </div><div class="col-sm">
                11 of 12  
                </div><div class="col-sm">
                12 of 12  
                </div>
            </div>
        </div>


        <p>Container fluid layout Medium ≥768px</p>
        <div id="first">
            <div class="row">
                <div class="col-md">
                12
                </div>
            </div>
        </div>
        <div id="second">
            <div class="row">
                <div class="col-md">
                6 of 12
                </div>
                <div class="col-md">
                12 of 12
                </div>            
            </div>
        </div>
        <div id="third">
            <div class="row">
                <div class="col-md">
                3 of 12
                </div>
                <div class="col-md">
                6 of 12
                </div>
                <div class="col-md">
                9 of 12
                </div>
                <div class="col-md">
                12 of 12
                </div>
            </div>
        </div>
        <div id="forth">
            <div class="row">            
                <div class="col-md">
                4 of 12
                </div>
                <div class="col-md">
                8 of 12
                </div>
                <div class="col-md">
                12 of 12
                </div>
            </div>
        </div>
        <div id="fifth">
            <div class="row">
                <div class="col-md">
                2 of 12
                </div>
                <div class="col-md">
                4 of 12
                </div>
                <div class="col-md">
                6 of 12
                </div>
                <div class="col-md">
                8 of 12
                </div>
                <div class="col-md">
                10 of 12
                </div>
                <div class="col-md">
                12 of 12
                </div>
            </div>
        </div>
        <div id="sixth">
            <div class="row">
                <div class="col-md">
                1 of 12  
                </div>
                <div class="col-md">
                2 of 12  
                </div>
                <div class="col-md">
                3 of 12 
                </div>
                <div class="col-md">
                4 of 12 
                </div>
                <div class="col-md">
                5 of 12  
                </div>
                <div class="col-md">
                6 of 12  
                </div>
                <div class="col-md">
                7 of 12  
                </div>
                <div class="col-md">
                8 of 12  
                </div>
                <div class="col-md">
                9 of 12  
                </div>
                <div class="col-sm">
                10 of 12  
                </div>
                <div class="col-md">
                11 of 12  
                </div>
                <div class="col-md">
                12 of 12  
                </div>
            </div>
        </div>



        <p>Container fluid layout Large ≥992px</p>
        <div id="first">
            <div class="row">
                <div class="col-lg">
                12
                </div>
            </div>
        </div>
        <div id="second">
            <div class="row">
                <div class="col-lg">
                6 of 12
                </div>
                <div class="col-lg">
                12 of 12
                </div>            
            </div>
        </div>
        <div id="third">
            <div class="row">
                <div class="col-lg">
                3 of 12
                </div>
                <div class="col-lg">
                6 of 12
                </div>
                <div class="col-lg">
                9 of 12
                </div>
                <div class="col-lg">
                12 of 12
                </div>
            </div>
        </div>
        <div id="forth">
            <div class="row">            
                <div class="col-lg">
                4 of 12
                </div>
                <div class="col-lg">
                8 of 12
                </div>
                <div class="col-lg">
                12 of 12
                </div>
            </div>
        </div>
        <div id="fifth">
            <div class="row">
                <div class="col-lg">
                2 of 12
                </div>
                <div class="col-lg">
                4 of 12
                </div>
                <div class="col-lg">
                6 of 12
                </div>
                <div class="col-lg">
                8 of 12
                </div>
                <div class="col-lg">
                10 of 12
                </div>
                <div class="col-lg">
                12 of 12
                </div>
            </div>
        </div>
        <div id="sixth">
            <div class="row">
                <div class="col-lg">
                1 of 12  
                </div>
                <div class="col-lg">
                2 of 12  
                </div>
                <div class="col-lg">
                3 of 12 
                </div>
                <div class="col-lg">
                4 of 12 
                </div>
                <div class="col-lg">
                5 of 12  
                </div>
                <div class="col-lg">
                6 of 12  
                </div>
                <div class="col-lg">
                7 of 12  
                </div>
                <div class="col-lg">
                8 of 12  
                </div>
                <div class="col-lg">
                9 of 12  
                </div>
                <div class="col-lg">
                10 of 12  
                </div>
                <div class="col-lg">
                11 of 12  
                </div>
                <div class="col-lg">
                12 of 12  
                </div>
            </div>
        </div>
    </div> <!--container-fluid-->

    <div class="container">
        <p>Variable width content</p>
        <div id="seventh">
            <div class="row justify-content-md-center">
                <div class="col col-lg-2">
                    1 of 3
                </div>
                <div class="col-md-auto">
                    Variable width content
                </div>
                <div class="col col-lg-2">
                    3 of 3
                </div>
            </div>
        </div>
        <div id="eight">
            <div class="row">
                <div class="col">
                    1 of 3
                </div>
                <div class="col-md-auto">
                    Variable width content
                </div>
                <div class="col col-lg-2">
                    3 of 3
            </div>
        </div>
        <div id="ninth">
            <p>Equal-width</p>
            <div class="row">
                <div class="col">
                    <div id="col1">
                        1 of 2
                    </div>
                </div>
                <div class="col">
                    <div id="col2">
                    2 of 2
                    </div>
                </div>
            </div>
        </div>
        <div id="tenth">    
            <div class="row">
                <div class="col">
                    <div id="col1">
                        1 of 3
                    </div>
                </div>
                <div class="col">
                    <div id="col2">
                         2 of 3
                    </div>
                </div>
                <div class="col">
                    <div id="col3">
                        3 of 3
                    </div>    
                </div>
            </div>
        </div>
        
        <p>Setting one column width</p>
        <div id="eleventh">
            <div class="row">
                <div class="col">
                    <div id="col1">
                        1 of 3
                    </div>
                </div>
                <div class="col-6">
                    <div id ="col2">
                        2 of 3 (wider)
                    </div>
                </div>
                <div class="col">
                    <div id="col3">
                        3 of 3
                    </div>
                </div>
            </div>
        </div>
        <div id="twelveth">
            <div class="row">
                <div class="col">
                    <div id="col1">
                        1 of 3
                    </div>
                </div>
                <div class="col-5">
                    <div id="col2">
                        2 of 3 (wider)
                    </div>
                </div>
                <div class="col">
                    <div id="col3">
                        3 of 3
                    </div>
                </div>
            </div>
         </div>
        
    </div><!---container--->

</div><!--grid1--->

<?php get_footer();?>