<?php get_header('taggle');?>

<div id="contact">
  
    <div class="card">
      
      <div class="card-body">

        <h5 class="card-title">GitHub overview</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="" class="btn btn-danger">GitHub overview</a>
      
        <p></p>

        <h5 class="card-title">GitHub Page</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="" class="btn btn-danger">GitHub page</a>

        <p></p>

        <h5 class="card-title">CodePen </h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="" class="btn btn-danger">CodePen</a>

        <p></p>
   
        <h5 class="card-title">LinkedIn </h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
        <a href="" class="btn btn-danger">LinkedIn</a>

        <p></p>
   
        <h5 class="card-title">Legal form</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

        <p></p>

        <h5 class="card-title">Contact information</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>


      </div>
    </div>  
<div>

<?php get_footer();?>
