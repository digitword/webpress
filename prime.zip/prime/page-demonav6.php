<?php get_header('demonav6');?>

<div class="container">
    <div id="nav6"> 
        <h1>A page with animated side navigation</h1>
    </div>
</div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<?php get_footer();?>