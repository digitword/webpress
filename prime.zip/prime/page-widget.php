<?php
/* 
 Template Name: frontpage/Home (as an example)
 */
?>

<?php get_header("demonav3");?>


<section class="page-wrap">
    <div class="container">

    <br></br>
        <section class="row">

            <div class="col-lg-3">
                <?php if ( is_active_sidebar( 'page-sidebar' ) ) : ?>
                    <?php dynamic_sidebar( 'page-sidebar' ); ?>
                <?php endif; ?>
            </div>

            <div class="col-lg-9">
                <br></br>
                <h3><?php the_title();?></h3>
                <br></br>
                <!---for editing text direclty from the wordpress editor--->
                <?php get_template_part('includes/section','content');?>
                <?php get_search_form();?>

            </div>
        </section>
    </div>
</section>

<?php get_footer();?>


