

const navButton = document.querySelector('.nav-botton');
const navOpen = document.querySelector('nav-open');

//const tween = TweenLite.to(object , time , {animate})
const tween = TweenLite.to('.cover' , 1 , {
    width:"40%"
});