//import 'bootstrap'; ????(should be there but gives error)

//IMPROVE YOUR

//require ('jquery');//= require jquery
//require ('bootstrap');//= require bootstrap-sprockets
//requuire ('bootstrap-sprockets');
//bootstrap/js/src/tools
//@import 'node_modules/bootstrap/src/tools/ccollapse';
//import 'node_modules/bootstrap/src/tools/collapse';
import 'bootstrap';
//import 'es6-promise';
//import 'exports-loader';
import 'jquery';
import 'jquery-ui';
//import 'font-awesome';
//Gsap
//import gsap from "gsap";
//import { gsap, TweenMax, TimelineLite} from 'gsap';

//const navButton = document.querySelector('.nav-botton');
//const navOpen = document.querySelector('nav-open');

//const tween = TweenLite.to(object , time , {animate})
//const tween = TweenLite.to('.cover' , 1 , {width:"40%"});

//import './navigation';
//import './slidepanel';
//import './stickycursor';
//import './templatepagination';


//import Swiper from 'swiper';
//import 'swiper/swiper-bundle.css';
//https://swiperjs.com/get-started/

//import Swup from "swup";

//import SwupFadeTheme from '@swup/fade-theme';
//import SwupSlideTheme from '@swup/slide-theme';


//const swup = new Swup({
    //plugins: [new SwupFadeTheme()],
    //plugins: [new SwupSlideTheme()]
  //});

//////

// jQuery Plugin: http://flaviusmatis.github.io/simplePagination.js/
/*
var items = $(".list-wrapper .list-item");
    var numItems = items.length;
    var perPage = 4;

    items.slice(perPage).hide();

    $('#pagination-container').pagination({
        items: numItems,
        itemsOnPage: perPage,
        prevText: "&laquo;",
        nextText: "&raquo;",
        onPageClick: function (pageNumber) {
            var showFrom = perPage * (pageNumber - 1);
            var showTo = showFrom + perPage;
            items.hide().slice(showFrom, showTo).show();
        }
    });

*/

import Swup from 'swup';
//const swup = new Swup(); // only this line when included with script tag
