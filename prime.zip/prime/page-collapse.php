<?php get_header('demonav3');?>

<div class="container">
<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Action
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="https://google.com/">Action</a>
    <a class="dropdown-item" href="https://google.com/">Another action google link</a>
    <a class="dropdown-item" href="#">Something else here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Separated link</a>
  </div>
</div>
<div class="col-xs-12">
  <div class="console"></div>
</div>

</div>
<?php get_footer();?>