<?php get_header('demonav3');?>

<section class="page-wrap">
    <div class="container">

        <br></br> 
           <h1>Search Results:</h1>

        <!-- This is our loop--->
        <?php get_template_part('includes/section','searchresults');?>
        

        <!----this is the first way for pagiantion (after limiting the numbe rof posts in a page in setting)-->
        <?php previous_posts_link();?>
        <?php next_posts_link();?>

       
    </div>
    

</section>


<?php get_footer();?>

<!-----

If category.php does not exist, WordPress will look for a generic archive template, archive.php.
https://developer.wordpress.org/themes/basics/template-hierarchy/

-->