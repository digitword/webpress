<?php get_header('taggle');?>

 <!---Ssection-content for editing text direclty from the wordpress editor--->
 <?php //get_template_part('includes/section','content');?>

<div id="gateway">  
  <div class="jumbotron">
    <h1 class="display-4">Be authentic and confidant!</h1>
    <p class="lead"> There are many ways to create a "WordPress" theme. 
      You can steal it by downloading one and making some minor modifications, 
      put your name on and upload it in "WordPress" and or "Themforest" for sell. 
      Another common way is using some website builders like "Elemnetor" which help you to create 
      and edit websites by employing the drag and drop technique without having to write any code.
      Honestly, none of these ways are my way because both have their own limitations 
      which restrict my capacity to design whatever I want to design.
      Thus, I decided to get my hands dirty, be authentic and confidant and do some serious jobs which 
      make me proud of that little creative creature inside of me!</p>  
  </div>
</div><!--gateway-->

  <div class="container">
  
  <div class="card text-center">
    <div class="card-header">
      <h4> Getting Started </h4>
    </div>
    <div class="card-body">
      <h5 class="card-title">WordPress template vs WordPress theme</h5>
      <p class="card-text">
      <P><strong>WordPress (WP, WordPress.org)</strong> is a free and open-source
      <strong>content management system (CMS)</strong> written in PHP and paired with a MySQL or MariaDB database. 
        Features include a plugin architecture and a template system, referred to within WordPress as Themes.
        <strong>WordPress templates </strong>differ to <strong>WordPress themes </strong>in that they
      only pertain to certain website pages, and not to an entire website. In other words, 
      a template is a <strong> single-page layout or a singe room</strong> that's available within a 
      WordPress theme as a part of the <strong>house</strong>. Thus, the theme is the design of your whole website 
      while the template is the layout of a single page of your site.
      In this opening chapter you can find some of my template examples.</p>
      <!---<a href="#" class="btn btn-success">Themes</a>--->
      <h5 class="card-title">Page Templates</h5>
      <p>Page templates are a specific type of template file that 
      can be applied to a specific page or groups of pages. They are used to change the look and feel of a 
      page and can be applied to a single page, a page section, or a class of pages. Generally speaking,       
      pages are a <strong>static Post Type </strong>, outside of the normal blog stream/feed. They 
      <strong>non-time dependent</strong> and without a time stamp
      are <strong>not organized</strong> using the categories and/or tags taxonomies
      can have page templates applied to them
      can be organized in a hierarchical structure — i.e. pages can be parents/children of other pages.
      You may decide that you want your homepage to look a specific way, that is quite 
      different to other parts of your site. Or, you may want to display a 
      featured image that links to a post on one part of the page, 
      have a list of latest posts elsewhere, and use a custom navigation.</p>      
    </div>           
  </div>
    <div class="card-footer text-muted">
         As of WordPress 4.7 page templates support all post types.
         For more details how to set a page template to specific post types see 
         <a href ="https://developer.wordpress.org/themes/template-files-section/page-template-files/#creating-page-templates-for-specific-post-types">
          WordPress Theme Handbook</a>.
    </div>   
  <!----------------------Responsive caption over image in carousel, how ? ------------------------------------>

  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators carousel-indicators-numbers">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active">0</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1">1</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2">2</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="3">3</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="4">4</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="5">5</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="6">6</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="7">7</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="8">8</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="9">9</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="10">10</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="11">11</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="12">12</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="13">13</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="14">14</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="15">15</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="16">16</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="17">17</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="18">18</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="19">19</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="20">20</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="21">21</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="21">22</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="22">23</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="23">24</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="24">25</li>
      <li data-target="#carouselExampleIndicators" data-slide-to="25">26</li>
      </ol>
              
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="First slide">
            <div class="carousel-caption d-none d-md-block" >
              <h5>WordPress navbar template</h5>
              <p>WordPress pages without navigation bar, with different 
              navigation color style, different menu items and animated side navigation.
              Chenkout the following examples:
              <a href="https://pupaak.com/demonav1/" class="badge badge-pill badge-success">Demo</a>
              <a href="https://pupaak.com/demonav2/" class="badge badge-pill badge-danger">Demo</a>
              <a href="https://pupaak.com/demonav3/" class="badge badge-pill badge-warning">Demo</a>
              <a href="https://pupaak.com/demonav5/" class="badge badge-pill badge-info">Demo </a>
              <a href="https://pupaak.com/demonav6/" class="badge badge-pill badge-success">Demo </a>
              </p> 
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Second slide">
            <div class="carousel-caption d-none d-md-block">
              <h5>WordPress footer template</h5>
              <p>A WordPress page with responsive footer and different menu 
              items than navigation menu in header, including subscribe form and social media links.
              Chenkout the following example:
              <a href="https://pupaak.com/demofoot2/" class="badge badge-pill badge-success">Demo </a>
              </p>
            </div>
          </div>        
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <h5>WordPress template layout and grid system</h5>
              <p>A WordPress page with container (fluid) layouts in different sizes,
              variable width content, equal-width and setting one column width.
              Chenkout the following example:</p>
              <a href="https://pupaak.com/demogrid1/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <h5>WordPress template with Carousel</h5>
              </p>The carousel is a slideshow for cycling through a series of content, 
              built with CSS 3D transforms and a bit of JavaScript. It works with a series 
              of images, text, or custom markup. It also includes support for previous/next 
              controls and indicators. Chenkout the following examples:
              <a href="https://pupaak.com/carousel" class="badge badge-pill badge-success">Demo</a>
              <a href="https://pupaak.com/carousel2/" class="badge badge-pill badge-danger">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <h5> WordPress template with parallax scrolling effect</h5>
              <p>Parallax scrolling effect Parallax effect is a modern web design technique where 
              background element scrolls slower than foreground content. This effect adds depth to 
              the background images and makes them feel interactive. Parallax effect can be used on landing pages,
              longform content, sales pages, or homepage of a business website.
              Chenkout the following example:
              <a href="https://pupaak.com/parallax/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <h5> WordPress template with video</h5>
              <p> Background videos are one of the biggest trends in web design these days.Besides being eye-catching, when used effectively, 
              video backgrounds can encourage visitors to stay on a website longer and improve 
              conversion rates. You can add sound to your video(not suggested), texture and or 
              (clickable )text. Check out the following examples of WorPress page with 
              videbackground with(out) navigation bar and with(out)
              caption, with embeded video or YouTube link:
              <!---Fix video size for different screen sizes--->
              <a href= "https://pupaak.com/videobaground/" class="badge badge-pill badge-success">Demo</a>
              <a href= "https://pupaak.com/vidbacnav/" class="badge badge-pill badge-danger">Demo</a>
              <a href= "https://pupaak.com/videobackcap/" class="badge badge-pill badge-warning">Demo</a>
              <a href= "https://pupaak.com/embedvideo/" class="badge badge-pill badge-info">Demo </a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <h5>WordPress template with media object</h5>
              <p>The media object helps build complex and repetitive components where some 
                media is positioned alongside content that doesn’t wrap around said media 
                for highly repetitive components like blog comments, tweets, and the like. 
                They can be nested or aligend with flexbox utilities to the top (default), 
                middle, or end of our content. Check out the following examples:</p>
              <a href="https://pupaak.com/mediaobject/" class="badge badge-pill badge-success">Demo</a>
            </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <h5> WordPress template with tables and forms</h5>
                <p>Make sure your website standout with powerful responive table and online 
                form templates for contact forms, signup forms, order forms, and more! By default, 
                WordPress does not come with a built-in contact form, but there are some easy 
                ways to add responsive contact forms to your site. Check out the following examples:
                <a href="https://pupaak.com/tableform/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <h5>WordPress template with alert</h5>
              <p> 
                When an alert box pops up, the user will have to click "OK" to proceed.
                Provide contextual feedback messages for typical user actions with the 
                handful of available and flexible alert messages:
                <a href="https://pupaak.com/alert/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
                <h5>WordPress template with badge and breadcomb</h5>
                <p>Badges can be used as part of links or buttons to provide a counter.
                The styling of badges provides a visual cue as to your purpose, 
                by simply presenting the content of the badge. 
                Depending on the specific situation, badges may seem 
                like random additional words or numbers at the end of a sentence, link, or button.
                Using color to add meaning only provides a visual indication.
                Breadcrumbs provide a navigation, it’s a good idea to add a meaningful 
                label to describe the type of navigation provided. Check out the following examples:
                <a href="https://pupaak.com/badges/" class="badge badge-pill badge-success">Demo</a>
                </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with image</h5>
                <p>First things first, you need high quality images (300 dpi). Your website background 
                image will usually be the first element that loads on the page, being the first thing 
                users see. So if you want users to see the value in your site when using a background 
                image, you'll need to use high quality visuals.The transparency of the image depends you. 
                Like video background you can add text Navigation menu and or texture to your image.
                Check out the following examples for imagebackground with(out) filter, with(out) caption
                and navigation menue and image gallery:
                <a href="https://pupaak.com/imagebackground/" class="badge badge-pill badge-success">Demo</a>
                <a href="https://pupaak.com/imagefilter/" class="badge badge-pill badge-danger">Demo</a>
                <a href="https://pupaak.com/imagenav/ " class="badge badge-pill badge-warning">Demo</a>
                <a href="https://pupaak.com/imagegallery/" class="badge badge-pill badge-info">Demo </a>
                </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <h5>WordPress template and bottons and botton group</h5>
                <p>Bootstrap includes several predefined button styles, each serving its own semantic 
                  purpose, with a few extras thrown in for more control. They can be presented in 
                  active or passive state. You can link them to different functionality and or use 
                  colour to convey your purpose. Checkbox fields allow the user to select one or more 
                  options and boxes can be checked and unchecked. Radio Buttons fields will allow only 
                  one option to be selected. A Radio Button cannot be unchecked.
                <a href="https://pupaak.com/bottons/" class="badge badge-pill badge-success">Demo</a>
                </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with cards</h5>
              <p>A card is a flexible and extensible content container. 
              It includes options for headers and footers, a wide variety of content, contextual 
              background colors, and powerful display options. If you’re familiar with Bootstrap 3,
              cards replace our old panels, wells, and thumbnails. Similar functionality to those
              components is available as modifier classes for cards.
              Check out our examples:
              <a href="https://pupaak.com/cards/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with input group</h5>
              <p>Easily extend form controls by adding text, buttons, or button groups on either side of 
              textual inputs, custom selects, and custom file inputs. Place any checkbox or radio
              option within an input group’s addon instead of text. Multiple add-ons are supported 
              and can be mixed with checkbox and radio input versions. Check out the following 
              example:
              <a href="https://pupaak.com/inputgroup/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5> WordPress template with Jombutrone </h5>
            <p> Jombotroen are a lightweight, flexible component that can optionally 
                extend the entire viewport to showcase key marketing messages on your site.
                Chekout our following example:
              <a href="https://pupaak.com/jumbotron/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5> WordPress template with listgroup </h5>
            <p> List groups are a flexible and powerful component for displaying a series 
              of content. Modify and extend them to support just about any content within. They 
              can include active and or disabled component, links and bottons, with badges
              with customized content. By using Javascript plugin, we can create a list group of
              tabbable pans of local content. Checnk out the following examples:
              <a href="https://pupaak.com/listgroup/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with Modals</h5>
              <p>by using Bootstrap’s JavaScript modal plugin we can add dialogs to our websitefor 
              lightboxes, user notifications, or completely custom content.
              When modals become too long for the user’s viewport or device, 
              they scroll independent of the page itself. Try the demo 
              below to see what we mean.
              Tooltips and popovers can be placed within modals as needed. 
              When modals are closed, any tooltips and popovers within are also 
              automatically dismissed.
            <a href="" class="badge badge-pill badge-success">Demo</a>
            </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5> WordPress template with navs</h5>
              <p>Open demos and check out examples of navigation menue bar in your WordPress
              website.</p>
			        <p>
              <a href="" class="badge badge-pill badge-success">Demo</a>
              <a href="" class="badge badge-pill badge-danger">Demo</a>
              <a href="" class="badge badge-pill badge-warning">Demo</a>
              <a href="" class="badge badge-pill badge-dark">Demo </a>
              <a href="" class="badge badge-pill badge-info">Demo </a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with popovers</h5>
              <p>Popovers provide additional information when you click on the button.
              Open demos to find out popover examples.
              <a href="" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with scrollspy</h5>
              <p>Open demos and check out examples of scrollspy behaviour in your WordPress website.
              https://www.w3schools.com/bootstrap/bootstrap_scrollspy.asp
              <a href="" class="badge badge-pill badge-success">Demo</a> 
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with spinners, toasts and tooltips</h5>
              <p>Bootstrap “spinners” can be used to show the loading state in your projects.
              Toasts are lightweight notifications designed to mimic the push notifications 
              that have been popularized by mobile and desktop operating systems.
              Tooltip plugin generates content and markup on demand, 
              and by default places tooltips after their trigger element. 
              <a href="" class="badge badge-pill badge-success">Demo</a>
              <a href="" class="badge badge-pill badge-danger">Demo</a>
              <a href="" class="badge badge-pill badge-warning">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with borders</h5>
              <p>Use border utilities to add or remove an element’s borders. 
                Choose from all borders or one at a time.
              <a href="" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with clearfix and close icone</h5>
              <p>The following example shows how the clearfix can be used. Without the clearfix the wrapping
              div would not span around the buttons which would cause a broken layout. we Use a generic close 
              icon for dismissing content like modals and alerts.
              <a href="" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5> WordPress template with colors and background gradient</h5>
              <p>Along with a well designed user-interface, helping visitors to navigate through 
              the site is one key role colour plays, guiding them through the site content easily 
              and quickly. Colour also helps towards building a content hierarchy, focusing attention
                on key information and calls to action.
              <a href="" class="badge badge-pill badge-success">Demo</a>
              <a href="" class="badge badge-pill badge-danger">Demo</a>
              <a href="" class="badge badge-pill badge-warning">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with flex and float</h5>      
              <p>Quickly manage the layout, alignment, and sizing of grid columns, navigation, components, 
              and more with a full suite of responsive flexbox utilities. Through toggle floats on any element, 
              across any breakpoint, using responsive float utilities.
              <a href="" class="badge badge-pill badge-success">Demo</a>
              <a href="" class="badge badge-pill badge-danger">Demo</a>
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with iamge replacement and position</h5>
              <p>Swap text for background images with the image replacement class.
              Swap text for background images with the image replacement class.Swap text 
              for background images with the image replacement class.
            <a href="" class="badge badge-pill badge-success">Demo</a>
            </p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="https://pupaak.com/wp-content/uploads/2021/02/pexels-irina-iriser-1420008.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            <h5>WordPress template with collaps and dropdown</h5>
            <p> The collapse JavaScript plugin is used to show and hide content. 
              Buttons or anchors are used as triggers that are mapped to specific elements you toggle. 
              Using the card component, we can extend the default collapse behavior to create 
              an accordion. Dropdown are built toggleable. They are toggled by clicking,
                not by hovering.
              <a href="https://pupaak.com/collapse/" class="badge badge-pill badge-success">Demo</a>
              </p>
            </div>
          </div>
        

        </div> <!---class="carousel-inner"--->

        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
        </a>
      </div><!----id="carouselExampleIndicators"--->
      <div class="card-footer text-muted">
      <strong>Notes:</strong> Just click on <strong>"demo"</strong> 
      and it leads you to a singel tamplate page. Here, as you see, I am not using pagination,
      but carousel slides. <strong>"Pagiantion"</strong> in WordPress is only provided for WordPres blog
      which I demonstrate in the <strong>blog</strong> section. 
      But if you want to see how pagiantion can work out in non-blog page, refer to <strong>UX&UI</strong> section
      in menu bar. 
      </div>  

    <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
        <div class="card text-white bg-info mb-3" style="">
            <div class="card-header"><h5>Post Templates</h5></div>
            <div class="card-body">
              <h6 class="card-title">Blog Post</h6>
              <p class="card-text">
              Indicating to <strong>blog</strong> leads us to another kind of templates which are called post templates.
              The Post types purpose is to categorize what type of 
              content we are dealing with. Generally speaking, <strong>Posts</strong> 
              are used in <strong>Blogs</strong>. 
              They displaye in reverse sequential order by time, with the newest post first. They 
              have a date and time stamp and may have the default taxonomies of categories
               and tags applied are used for creating feeds.                         
               In the following section, you can finds some of blog templates:
              </p>
            </div>
          </div>
          <div class="card-footer text-muted">
          <strong>Notes:</strong> Think of <strong>pages</strong> as your static content or “one-off” kind of content
            that will seldom need changing. This might for example be your About page, and is seen 
            as timeless entities. <strong>Posts</strong> on the other hand are your blog entries or dynamic 
             content that gets added regularly. 
          </div>  
    </div><!--class="shadow-lg p-3 mb-5 bg-white rounded"---->
      

    <div class="row">
      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <h5>WordPress template with categories</h5>
          <p>A category symbolizes (a) topic(s) that are connected
           to one another in some way. Sometimes, 
            a post can belong to many categories at the same time. 
            In this demo you find two categories 'Çooking book'
            and 'Traveling book'. As you see 'Article test 1' belongs to
            both of them. You can also use tages as keywords used for 
            topics discussed in a particular post.</p>
          <a href="https://pupaak.com/article-test1/" class="badge badge-pill badge-success">Demo</a>
        </div>
      </div>

      <div class="col-sm">
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <h5>WordPress template with thumbnail and pagination</h5>
          <p>Post thumbnails are the primary image for your blog posts, 
            and they often appear next to the heading on your home page and social media. 
            Pagination allows your user to page back and forth through multiple pages of content. 
            WordPress can use pagination when: Viewing lists of posts when more posts exist than can fit on one page, 
            or. Breaking up longer posts by manually by using the following tag.          
          </p>
        <a href="https://pupaak.com/category/world/" class="badge badge-pill badge-success">Demo</a>
        </div>
      </div>
    </div> <!--row16-->

    <div class="row">
      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <h5>WordPress template with forms</h5>
          <p>Categories are the most general method of grouping content 
          on a WordPress site. A category symbolizes a topic or a group of 
          topics that are connected to one another in some way. Sometimes, 
          a post can belong to many categories at the same time.</p>
          <a href="" class="badge badge-pill badge-success">Demo</a>
        </div>
      </div>

      <div class="col-sm">
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <h5>WordPress template with sidebars for widgets</h5>
          <p>A sidebar is any widgetized area of your theme. Widget areas are 
          places in your theme where users can add their own widgets. 
          In the following demos you can observe "post archive", "post categories", 
          "last post" and "search" in blog posts and also "website menu" and "calender" for post events, in 
          a specific page.Client can choose their desired wigedts is sidebar 
          from widget section.</p>
        <a href="https://pupaak.com/category/tasty/" class="badge badge-pill badge-success">Demo</a>
        <a href="https://pupaak.com/widget/" class="badge badge-pill badge-danger">Demo</a>

        </div>
      </div>
    </div> <!--row16-->
    
    <div class="row">
      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <h5>WordPress template with search item</h5>
          <p>You can use search function in sidebar as a widget
           or wherever you want.For example, if you type the word "Chocolate" in serch section, 
          all of the pages and blog posts which contain this word, will show up, unless you set in advance in 
          which category you want to limit your search result. 
          The following demos provide you with such 
          examples in blog posts and page post. Try to search "water"
          and see the result.</p>
          <a href="https://pupaak.com/category/world/" class="badge badge-pill badge-success">Demo</a>
          <a href="https://pupaak.com/widget/" class="badge badge-pill badge-danger">Demo</a>

        </div>
      </div>

      <div class="col-sm">
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <h5>WordPress template with shopping page</h5>
          <p></p>
        <a href="" class="badge badge-pill badge-success">Demo</a>
        </div>
      </div>
    </div> <!--row16-->
    
    
    <!----Special title treatment--->
    <div class="card text-center">
      <div class="card-header">
      Last update 20/04/2021
      </div>
      <div class="card-body">
        <h5 class="card-title">Contact info:</h5>
        <p class="card-text">Email addresses: neghah@pupaak.com & info@pupaak.com.</p>
        <a href="https://github.com/digitword" class="btn btn-info">GitHub </a>
      </div>
      <div class="card-footer text-muted">
      KvK number: 78339006, © 2020 Pupaak. All rights reserved. 
      </div>
    </div>

      </div> <!----container-->

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.4/pagination.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.4/pagination.css"/>
      <script src="/js/jquery-1.11.1.min.js"></script>
      <script src="/js/bootstrap.min.js"></script>


<?php get_footer();?>
