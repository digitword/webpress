<!DOCTYPE html>
<main id="swup" class="transition-fade">

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Documentry</title>
  <?php wp_head();?>  
</head>

<body>

<header>
    <div id="toggle">
    <img src="#" alt="Show" /></div>
    <div id="popout">
    <?php wp_nav_menu( array( 'theme_location' => 'top-menu', 'menu_class' => 'nav-menu' ) ); ?>
    </div>
</header>