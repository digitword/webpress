<?php get_header("demonav3");?>


<section class="page-wrap">
    <div class="container">



    


        <br></br>
        <h3><?php the_title();?></h3>
        <br></br>
        <!---for editing text direclty from the wordpress editor--->
        <?php get_template_part('includes/section','content');?>


    </div>
</section>

<?php get_footer();?>