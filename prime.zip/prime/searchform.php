<form action="/" methode="get">

    <label for="search">Search</label>

    <!--You can choose the domain of your searching. If you hold your -->
    <input type="hidden" name="cat" value="">    
    <input type="text" name="s" id="search" value="<?php the_search_query();?>" required>

    <button type="submit"> Search!</button>

</form>