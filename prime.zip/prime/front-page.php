<?php 
/*
Template Name: frontpage/Home
*/
?>

<?php get_header();?>

<div class="container">
    <h1><?php the_title();?></h1>
    <?php get_template_part('includes/section' , 'content');?>

        <div id="pupaak">                  
                <video loop muted autoplay preload="auto">
                    <source src="https://pupaak.com/wp-content/uploads/2020/12/lastwithtext.mp4" type="video/mp4">
                    Your brower does not support the video tag.
                </video>                  
                
                <div class="caption">
                    <h3> This website will be update on 16:30 (4:30 pm ) 20/04/2021<span>&nbsp;</span></h3>
                    <!--
                    <h2>Welcome to my WordPress world<h2>
                    <a class="btn btn-outline-secondary btn-sm"
                    href="https://pupaak.com/templates/" role="button">Open</a>
                    </button>-->
                </div>
        </div>              
</div>
<!---- add image loading Moziallz--->
<!--https://wickydesign.com/9-simple-add-ons-you-should-consider-for-your-website/ --->
<?php get_footer('pupaak');?>
