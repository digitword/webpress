<?php get_header('taggle');?>

 <!---Ssection-content for editing text direclty from the wordpress editor--->
 <?php //get_template_part('includes/section','content');?>

<div id="way">  
  <div class="jumbotron">
        <h1 class="display-4">Let's see how! </h1>
        <p class="lead"> 
        <li> Using Laravel Mix in a WordPress Theme</li>
        </p>  
  </div>
</div><!--way-->

<div class="container">
  <h2>Using Laravel Mix in a WordPress Theme</h2>
  <p><strong>User experience (UX)</strong> is the interaction and experience users 
  have with an app or product. The experience might be smooth, positive, confusing or intuitive. 
  It might also involve whether the application feels arbitrary or logical. <strong>User interface (UI)</strong> 
  https://www.smashingmagazine.com/2016/01/create-customize-wordpress-child-theme/<br></br>
  https://www.computerhope.com/issues/ch000049.htm#top <br></br>
  https://serversideup.net/using-laravel-mix-in-a-wordpress-theme/ <br></br>
  https://yossiabramov.com/blog/wordpress-and-laravel-mix <br></br>
</p>
  
  <br></br>

  


</div><!---container-->
<!----Special title treatment--->
<div class="card text-center">
      <div class="card-header">
      Last update 20/04/2021
      </div>
      <div class="card-body">
      <h5 class="card-title">Contact info:</h5>
        <p class="card-text">Email addresses: neghah@pupaak.com & info@pupaak.com.</p>
        <a href="https://github.com/digitword" class="btn btn-info">GitHub </a>
      </div>
      <div class="card-footer text-muted">
      KvK number: 78339006, © 2020 Pupaak. All rights reserved. 
      </div>
    </div>

      </div> <!----container-->

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.4/pagination.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.4/pagination.css"/>
      <script src="/js/jquery-1.11.1.min.js"></script>
      <script src="/js/bootstrap.min.js"></script>
<?php get_footer();?>

<!--why return bacl to page manipulating fade is sometimes is difficult-->
<!--https://react-bootstrap.github.io/getting-started/introduction/-->
<!---https://medium.com/@nedsoft/how-to-add-jquery-ui-plugin-to-a-laravel-app-using-laravel-mix-e85bf0244fc1--->