<?php get_header('taggle');?>

<div id="uix">
    <div class="jumbotron">
      <h1 class="display-4">Be creative and resourceful!</h1>
      <p class="lead"> to contribute new ideas, designing initiative readily, independently, 
        and responsibly. Deal skilfully and promptly with new situations and obstacles. Think about 
        alternatives and visualize how something could be achieved when there is nothing there but vision. 
        To be resourceful takes self-discipline and iron will. All these qualities are grate but honestly,
         this is not always possible for me specially when I face with daily struggles. But I enjoy having 
         fun, trying new things and stretch my horizon to new opportunities. Who knows what lies around the corner? 
        Thus, let us get on board, not to be a passive observer and not to overthink the situation, just do it

      </p>
            
    </div><!--jumbotron-->
</div><!--unix-->


<div class="container">
  <h2>UX vs UI design</h2>
  <p><strong>User experience (UX)</strong> is the interaction and experience users 
  have with an app or product. The experience might be smooth, positive, confusing or intuitive. 
  It might also involve whether the application feels arbitrary or logical. <strong>User interface (UI)</strong> 
  refers to graphical layout of an app. It is comprised of buttons that the end-user of the app click,
   text they read, sliders, images and text entry fields. UI design also includes other items such 
   as interface animations, screen layouts, transitions and micro-interaction users usually interact with. 
   When creating a user interface, all visual elements, animation and interaction are designed.
   UX is usually determined by how hard or easy it is to interact with the interface elements created by UI designers.</p>
</div>

<div class="container">
   <div class="row">
      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/ocean.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">Animated page with CSS & HTMl</p>
                <a href="http://pupaak.test/animation/" class="badge badge-pill badge-success">Demo</a>
            </div>
        </div>
        </div>
      </div>

      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/davinchi.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">DaVinci Resolve edited videos</p>
                <a href="http://pupaak.test/davichi/" class="badge badge-pill badge-success">Demo</a>
            </div>
        </div>
        </div>
      </div>

      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/textgener.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">A text generated page</p>
                <a href="http://pupaak.test/textgener/" class="badge badge-pill badge-success">Demo</a>
            </div>
        </div>
        </div>
      </div>
      
    </row>    

</div><!--container-->

<div class="container">
   <div class="row">
      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/stickysect-2.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">A page with section transition</p>
                <a href="http://pupaak.test/stickysection/#s3" class="badge badge-pill badge-success">Demo</a>
            </div>
        </div>
        </div>
      </div>

      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/smothscroll-2.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text"> A page with Smooth Scroll </p>
              <a href="http://pupaak.test/anireload/#section1" class="badge badge-pill badge-success">Demo</a>
            </div>
        </div>
        </div>
      </div>

      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/paralpg.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text"> A page with Parallax effect</p>
                <a href="http://pupaak.test/parallax/" class="badge badge-pill badge-success">Demo</a>
            </div>
        </div>
        </div>
      </div>     
    </row> 
</div><!--container-->

<div class="container">
   <div class="row">
      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/videocan-4.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">A paege with video background </p>
                <a href="http://pupaak.test/vidbacnav/" class="badge badge-pill badge-success">Demo</a>
                <a href="http://pupaak.test/videobackcap/" class="badge badge-pill badge-primary">Demo</a>
                <a href="http://pupaak.test/videobaground/" class="badge badge-pill badge-danger">Demo</a>
            </div>
        </div>
        </div>
      </div>

      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/embedvideo-2.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text"> A page with embeded video</p>
                <a href="http://pupaak.test/embedvideo/" class="badge badge-pill badge-success">Demo</a>
            </div>
        </div>
        </div>
      </div>

      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/carousel-2.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text"> A page with carousel </p>
                <a href="http://pupaak.test/carousel2/" class="badge badge-pill badge-success">Demo</a>
                <a href="http://pupaak.test/carousel/" class="badge badge-pill badge-primary">Demo</a>
            </div>
        </div>
        </div>
      </div>     
    </row> 
</div><!--container-->

<!----Special title treatment--->
<div class="card text-center">
      <div class="card-header">
        Last update 20/04/2021
      </div>
      <div class="card-body">
      <h5 class="card-title">Contact info:</h5>
        <p class="card-text">Email addresses: neghah@pupaak.com & info@pupaak.com.</p>
        <a href="https://github.com/digitword" class="btn btn-info">GitHub </a>
      </div>
      <div class="card-footer text-muted">
      KvK number: 78339006, © 2020 Pupaak. All rights reserved. 
      </div>
    </div>

      </div> <!----container-->

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.4/pagination.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.4/pagination.css"/>
      <script src="/js/jquery-1.11.1.min.js"></script>
      <script src="/js/bootstrap.min.js"></script>


<?php get_footer();?>