<?php get_header('animation');?>


<div id= "bubble">
    <div class="hero">
        
        <div class="navbar">
          <img src="https://pupaak.com/wp-content/uploads/2021/04/imageedit_1_9935294902.png" class ="logo">
        </div>
       
        
        <div class="content">
          <mediium> welcome to my </medium>
          <h1>World's <br> Creative studio</h1>
          <a href="http://pupaak.test/ui/" class="btn btn-outline-light" role="button" aria-pressed="true">Back</a>
          <a href="http://pupaak.test/ui/" class="btn btn-outline-light" role="button" aria-pressed="true">Signup</a>

        </div>

        <div class="side-bar">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/menu.png" class="menu">
            <div class="social-links">
                <img src="https://pupaak.com/wp-content/uploads/2020/12/fb.png">
                <img src="https://pupaak.com/wp-content/uploads/2020/12/ig.png">
                <img src="https://pupaak.com/wp-content/uploads/2020/12/tw.png">
                
            </div> 
            <div class="useful-links">
                <img src="https://pupaak.com/wp-content/uploads/2020/12/share.png">
                <img src="https://pupaak.com/wp-content/uploads/2020/12/info.png">
            </div>
        </div>
        
        
        <div class="bubbles">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/bubble.png">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/bubble.png">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/bubble.png">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/bubble.png">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/bubble.png">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/bubble.png">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/bubble.png">
            <img src="https://pupaak.com/wp-content/uploads/2020/12/bubble.png">
        </div>


    </div>      
</div>



<?php get_footer('animation');?>