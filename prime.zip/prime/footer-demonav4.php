<footer>

<footer>
  <p>Author: Pupaak<br>
  <a href="mailto:hege@example.com">info@pupaak.com</a></p>
  <nav id="site-navigation" class="taggle-navigation" role="navigation">
        <?php wp_nav_menu( array( 'theme_location' => 'new-menu'  , 'menu_class' => 'nav-menu') ); ?>
  </nav>
</footer>

</body>

</html>