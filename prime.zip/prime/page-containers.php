<?php get_header('nonav');?>

<div class="container">
<h4>All-in-one</h4><h5>a responsive, fixed-width container, meaning its max-width changes at each breakpoint.</h5>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel tellus dapibus nisl tincidunt consectetur. Praesent ultrices elit vel condimentum consectetur. Sed sed quam interdum, accumsan magna ut, mollis elit. Praesent et lacus convallis, condimentum dui non, tempor arcu. Etiam commodo pulvinar elit quis porttitor. Sed commodo ante in ipsum euismod fermentum. Quisque at justo sit amet purus ultrices rutrum sed vel libero. Nulla in volutpat sapien. Duis eleifend tincidunt dui, nec finibus ipsum. Morbi facilisis sodales maximus. Cras ante neque, viverra sit amet ex nec, molestie laoreet arcu. Curabitur quis tortor nibh.</p>
</div>

<div class="container-fluid">
<h4>Fluid container</h4><h5>a full width container, spanning the entire width of the viewport.</h5>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel tellus dapibus nisl tincidunt consectetur. Praesent ultrices elit vel condimentum consectetur. Sed sed quam interdum, accumsan magna ut, mollis elit. Praesent et lacus convallis, condimentum dui non, tempor arcu. Etiam commodo pulvinar elit quis porttitor. Sed commodo ante in ipsum euismod fermentum. Quisque at justo sit amet purus ultrices rutrum sed vel libero. Nulla in volutpat sapien. Duis eleifend tincidunt dui, nec finibus ipsum. Morbi facilisis sodales maximus. Cras ante neque, viverra sit amet ex nec, molestie laoreet arcu. Curabitur quis tortor nibh.</p>
</div>

<h4>Responsive containers</h4><h5>100% wide until the specified breakpoint is reached, after which we apply max-widths for each of the higher breakpoints.</h5>
<div class="container-sm">
  <h4>100% wide until small breakpoint</h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel tellus dapibus nisl tincidunt consectetur. Praesent ultrices elit vel condimentum consectetur. Sed sed quam interdum, accumsan magna ut, mollis elit. Praesent et lacus convallis, condimentum dui non, tempor arcu. Etiam commodo pulvinar elit quis porttitor. Sed commodo ante in ipsum euismod fermentum. Quisque at justo sit amet purus ultrices rutrum sed vel libero. Nulla in volutpat sapien. Duis eleifend tincidunt dui, nec finibus ipsum. Morbi facilisis sodales maximus. Cras ante neque, viverra sit amet ex nec, molestie laoreet arcu. Curabitur quis tortor nibh.</p>
</div>
<div class="container-md">
<h4>100% wide until medium breakpoint</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel tellus dapibus nisl tincidunt consectetur. Praesent ultrices elit vel condimentum consectetur. Sed sed quam interdum, accumsan magna ut, mollis elit. Praesent et lacus convallis, condimentum dui non, tempor arcu. Etiam commodo pulvinar elit quis porttitor. Sed commodo ante in ipsum euismod fermentum. Quisque at justo sit amet purus ultrices rutrum sed vel libero. Nulla in volutpat sapien. Duis eleifend tincidunt dui, nec finibus ipsum. Morbi facilisis sodales maximus. Cras ante neque, viverra sit amet ex nec, molestie laoreet arcu. Curabitur quis tortor nibh.</p>
</div>
<div class="container-lg">
<h4>100% wide until large breakpoint</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel tellus dapibus nisl tincidunt consectetur. Praesent ultrices elit vel condimentum consectetur. Sed sed quam interdum, accumsan magna ut, mollis elit. Praesent et lacus convallis, condimentum dui non, tempor arcu. Etiam commodo pulvinar elit quis porttitor. Sed commodo ante in ipsum euismod fermentum. Quisque at justo sit amet purus ultrices rutrum sed vel libero. Nulla in volutpat sapien. Duis eleifend tincidunt dui, nec finibus ipsum. Morbi facilisis sodales maximus. Cras ante neque, viverra sit amet ex nec, molestie laoreet arcu. Curabitur quis tortor nibh.</p>
</div>
<div class="container-xl">
<h4>100% wide until extra large breakpoint</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel tellus dapibus nisl tincidunt consectetur. Praesent ultrices elit vel condimentum consectetur. Sed sed quam interdum, accumsan magna ut, mollis elit. Praesent et lacus convallis, condimentum dui non, tempor arcu. Etiam commodo pulvinar elit quis porttitor. Sed commodo ante in ipsum euismod fermentum. Quisque at justo sit amet purus ultrices rutrum sed vel libero. Nulla in volutpat sapien. Duis eleifend tincidunt dui, nec finibus ipsum. Morbi facilisis sodales maximus. Cras ante neque, viverra sit amet ex nec, molestie laoreet arcu. Curabitur quis tortor nibh.</p>
</div>    


<?php get_footer();?>