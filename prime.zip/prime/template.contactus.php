<?php 
/*
Template Name: Contact Us
*/
?>

<!---Pay attentio that there are two forms of pages. Template page (like this ob_end_clean
and standard page. Do not forget choosing template option, in page attribute section, in wordpress page 
editor, if you're using template page.)-->

<?php get_header('demonav3');?>

    <div class="container">
        <br></br>
        <h3><?php the_title();?></h3>
        <br></br>
        <div class="row">
            <div>
                <div class="col">
                    This is where contact form goes.
                </div>
            </div>
            <div>
                <div class="col">
                    <?php get_template_part('includes/section','content');?>
                </div>
            </div>
        </div>
        <br></br>
    </div>

<?php get_footer();?>