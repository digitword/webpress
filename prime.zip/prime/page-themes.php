<?php get_header('taggle');?>

 <!---Ssection-content for editing text direclty from the wordpress editor--->
 <?php //get_template_part('includes/section','content');?>

<div id="final">  
    <div class="jumbotron">
      <h1 class="display-4">Diversity</h1>
      <p class="lead"> 
        Diversity is desing! what is impoetant?
      </p>  
    </div>
</div><!--final-->


<div class="container">
  <h2>UX vs UI design</h2>
  <p><strong>User experience (UX)</strong> is the interaction and experience users 
  have with an app or product. The experience might be smooth, positive, confusing or intuitive. 
  It might also involve whether the application feels arbitrary or logical. <strong>User interface (UI)</strong> 
  refers to graphical layout of an app. It is comprised of buttons that the end-user of the app click,
   text they read, sliders, images and text entry fields. UI design also includes other items such 
   as interface animations, screen layouts, transitions and micro-interaction users usually interact with. 
   When creating a user interface, all visual elements, animation and interaction are designed.
   UX is usually determined by how hard or easy it is to interact with the interface elements created by UI designers.</p>
</div>

<div class="container">
   <div class="row">
      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/pexels-anna-tis-6832750-1-scaled.jpg" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">Coffeehouse </p>
              <p> wordepress version 5<p>
                <!--<a href="http://pupaak.test/animation/" class="badge badge-pill badge-success">Demo</a>-->
            </div>
        </div>
        </div>
      </div>

      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/pexels-liza-summer-6348129-scaled.jpg" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">Voluneer</p>
              <p> wordepress version 5<p>
              <!--  <a href="http://pupaak.test/animation/" class="badge badge-pill badge-success">Demo</a>-->
            </div>
        </div>
        </div>
      </div>

      <div class="col-sm">  
        <div class="shadow-lg p-3 mb-5 bg-white rounded"> 
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="http://pupaak.test/wp-content/uploads/2021/04/pexels-esrageziyor-7473033-1-scaled.jpg" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">Doly Vita</p>
                <!--<a href="http://pupaak.test/animation/" class="badge badge-pill badge-success">Demo</a>-->
                <p> wordepress version 5<p>

            </div>
        </div>
        </div>
      </div>
      
    </row>    

</div><!--container-->



<!----Special title treatment--->
<div class="card text-center">
      <div class="card-header">
      Last update 20/04/2021
      </div>
      <div class="card-body">
      <h5 class="card-title">Contact info:</h5>
        <p class="card-text">Email addresses: neghah@pupaak.com & info@pupaak.com.</p>
        <a href="https://github.com/digitword" class="btn btn-info">GitHub</a>
      </div>
      <div class="card-footer text-muted">
      KvK number: 78339006, © 2020 Pupaak. All rights reserved. 
      </div>
    </div>

      </div> <!----container-->

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.4/pagination.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.4/pagination.css"/>
      <script src="/js/jquery-1.11.1.min.js"></script>
      <script src="/js/bootstrap.min.js"></script>

<?php get_footer();?>